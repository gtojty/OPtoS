Input [0-2] 0 0
,
Output [2] 0
;
tag: This is an optional tag
Input [0-2] 0 1
,
Output [2] 1
;
Input [0-2] 1 0
,
Output [2] 1
;
Input [0-2] 1 1
,
Output [2] 0
;
