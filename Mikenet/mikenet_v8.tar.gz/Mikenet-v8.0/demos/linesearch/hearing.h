
extern Net *hearing,*sp,*ps;
extern Group *phonology,*psh,*semantics,*sem_cleanup,*pho_cleanup;
extern Connections * c[100],*hid_pho,*sem_hid;
extern int connection_count;
void build_hearing_model();
