float sample(Net *net,ExampleSet *examples,int from,int to,float lr);

Real g(Net *net,ExampleSet *examples,int from,int to);
Real f(Net *net,ExampleSet *examples,int from,int to);
