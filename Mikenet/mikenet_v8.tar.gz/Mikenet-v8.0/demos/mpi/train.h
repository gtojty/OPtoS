extern ExampleSet *hearing_examples,*speaking_examples;
extern ExampleSet *sem_examples,*phono_examples;
