void build_reading_model();
extern Net *reading;
extern Group *ortho,*oph,*osh,*pho_cleanup;
extern Connections *osh_conn,*hearbias;

