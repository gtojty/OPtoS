#define TIME 7

extern Net *reading;
extern Group *input,*hidden,*output,*phohid;
extern ExampleSet *reading_examples;
extern Connections *c1,*c2,*c3,*c4,*c5,*c6,*c7;

int build_model(void);
